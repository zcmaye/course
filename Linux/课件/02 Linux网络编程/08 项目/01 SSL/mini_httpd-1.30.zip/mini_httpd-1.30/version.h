/* version.h - version defines for mini_httpd */

#ifndef _VERSION_H_
#define _VERSION_H_

#define SERVER_SOFTWARE "mini_httpd/1.30 26Oct2018"
#define SERVER_URL "http://www.acme.com/software/mini_httpd/"

#endif /* _VERSION_H_ */
