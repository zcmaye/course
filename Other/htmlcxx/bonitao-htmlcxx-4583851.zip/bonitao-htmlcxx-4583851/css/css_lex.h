#ifndef __CSS_LEX_H__
#define __CSS_LEX_H__

int init_yylex(const char *buffer, int buf_len);
int end_yylex();

#endif
