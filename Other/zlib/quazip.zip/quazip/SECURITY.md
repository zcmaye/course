# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| master   | :white_check_mark: |
| v1.4+   | :white_check_mark: |

## Reporting a Vulnerability

Report a vulnerability to cen.is.imba (AT) gmail dot com.
Please follow coordinated vulnerability disclosure process and allow up to 90 days for a fix.
Even better if you also provide a patch.
