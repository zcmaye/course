<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MainWindowClass</name>
    <message>
        <location filename="../../AppTranslation/MainWindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation>It is App Main Window</translation>
    </message>
    <message>
        <location filename="../../AppTranslation/MainWindow.ui" line="26"/>
        <source>Change</source>
        <translation>change language</translation>
    </message>
</context>
<context>
    <name>Widget1</name>
    <message>
        <location filename="../../AppTranslation/Widget1.ui" line="14"/>
        <source>Widget1</source>
        <translation>it is widget 1</translation>
    </message>
    <message>
        <location filename="../../AppTranslation/Widget1.ui" line="26"/>
        <source>welldone</source>
        <translation>Well Done !</translation>
    </message>
</context>
<context>
    <name>Widget2</name>
    <message>
        <location filename="../../AppTranslation/Widget2.ui" line="14"/>
        <source>Widget2</source>
        <translation>it is widget 2</translation>
    </message>
    <message>
        <location filename="../../AppTranslation/Widget2.ui" line="26"/>
        <source>china</source>
        <translation>China!</translation>
    </message>
</context>
</TS>
