<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>MainWindowClass</name>
    <message>
        <location filename="../../AppTranslation/MainWindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation>主窗口</translation>
    </message>
    <message>
        <location filename="../../AppTranslation/MainWindow.ui" line="26"/>
        <source>Change</source>
        <translation>换语言</translation>
    </message>
</context>
<context>
    <name>Widget1</name>
    <message>
        <location filename="../../AppTranslation/Widget1.ui" line="14"/>
        <source>Widget1</source>
        <translation>窗口1</translation>
    </message>
    <message>
        <location filename="../../AppTranslation/Widget1.ui" line="26"/>
        <source>welldone</source>
        <translation>干得漂亮！</translation>
    </message>
</context>
<context>
    <name>Widget2</name>
    <message>
        <location filename="../../AppTranslation/Widget2.ui" line="14"/>
        <source>Widget2</source>
        <translation>窗口2</translation>
    </message>
    <message>
        <location filename="../../AppTranslation/Widget2.ui" line="26"/>
        <source>china</source>
        <translation>中华人民共和国</translation>
    </message>
</context>
</TS>
