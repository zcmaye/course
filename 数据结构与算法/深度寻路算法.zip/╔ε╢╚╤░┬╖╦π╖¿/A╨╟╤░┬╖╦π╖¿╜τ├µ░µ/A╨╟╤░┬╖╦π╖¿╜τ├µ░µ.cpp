﻿#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <graphics.h>


#define ROWS 10
#define COLS 10

//直线代价
#define ZXDJ 10
//斜线代价
#define XXDJ 14

#define SPACE 50

enum direct { p_up, p_down, p_left, p_right, p_lup, p_ldown, p_rup, p_rdown };

//点类型
struct MyPoint
{
	int row, col;
	int f, g, h;
};

//树节点最大孩子数
#define SIZE 8

//树节点类型
struct treeNode
{
	struct MyPoint		pos;

	struct treeNode*	pParent;

	struct treeNode*	child[SIZE];

	int					childNum;
};

IMAGE pos, ren, road, wall;

//创建树节点
struct treeNode* createTreeNode(struct MyPoint pos);
//标记是否走过
bool canWalk(struct MyPoint pos, int map[ROWS][COLS], bool isFindmap[ROWS][COLS]);

//计算h值
int getH(struct MyPoint pos, struct MyPoint endPos);

//贴图
void drawMap(int map[ROWS][COLS], struct MyPoint pos);

int main()
{
	//做窗口
	initgraph(COLS*SPACE, ROWS*SPACE,SHOWCONSOLE);
	//加载图片
	loadimage(&pos, "pos.bmp", SPACE/2, SPACE/2, true);
	loadimage(&ren, "ren.bmp", SPACE, SPACE, true);
	loadimage(&road,"road.bmp",SPACE, SPACE, true);
	loadimage(&wall,"wall.bmp",SPACE, SPACE, true);
	//地图
	int map[ROWS][COLS] =
	{
		{ 0, 0, 0, 0, 1, 0, 0, 0, 0, 0 },
		{ 0, 0, 1, 1, 1, 0, 0, 0, 0, 0 },
		{ 0, 1, 0, 1, 1, 0, 0, 0, 0, 0 },
		{ 0, 1, 1, 0, 1, 0, 0, 0, 0, 0 },
		{ 0, 0, 1, 1, 1, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 1, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 1, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 1, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 1, 0, 0, 0, 0, 0 }
	};

	//标记是否走过
	bool isFindmap[ROWS][COLS] = { 0 };

	//起点
	struct MyPoint begPos = { 1, 1 };
	//终点
	struct MyPoint endPos = { 6, 7 };

	//标记起点走过
	isFindmap[begPos.row][begPos.col] = true;

	//准备一棵树
	struct treeNode* pRoot = NULL;
	//起点入树
	pRoot = createTreeNode(begPos);

	//准备一个数组
	struct treeNode* buff[100] = { 0 };
	int				 buffLen = 0;

	//标记是否找到终点
	bool isFindEnd = false;
	//当前点
	struct treeNode* pCurrent = pRoot;
	struct treeNode* pTemp = NULL;

	int minIdx;


	while (1)
	{
		//遍历当前点周围八个点
		for (int i = 0; i < SIZE; i++)
		{
			pTemp = createTreeNode(pCurrent->pos);
			switch (i) //找出一个点
			{
			case p_up:
				pTemp->pos.row--;
				pTemp->pos.g += ZXDJ;
				break;
			case p_down:
				pTemp->pos.row++;
				pTemp->pos.g += ZXDJ;
				break;
			case p_left:
				pTemp->pos.col--;
				pTemp->pos.g += ZXDJ;
				break;
			case p_right:
				pTemp->pos.col++;
				pTemp->pos.g += ZXDJ;
				break;
			case p_lup:
				pTemp->pos.col--;
				pTemp->pos.row--;
				pTemp->pos.g += XXDJ;
				break;
			case p_rup:
				pTemp->pos.col++;
				pTemp->pos.row--;
				pTemp->pos.g += XXDJ;
				break;
			case p_ldown:
				pTemp->pos.col--;
				pTemp->pos.row++;
				pTemp->pos.g += XXDJ;
				break;
			case p_rdown:
				pTemp->pos.col++;
				pTemp->pos.row++;
				pTemp->pos.g += XXDJ;
				break;
			} // end of switch(i)

			//判断能不能走
			if (canWalk(pTemp->pos, map, isFindmap))//能走
			{
				//计算h
				pTemp->pos.h = getH(pTemp->pos, endPos);
				//计算f
				pTemp->pos.f = pTemp->pos.g + pTemp->pos.h;
				//入树
				pTemp->pParent = pCurrent;
				pCurrent->child[pCurrent->childNum] = pTemp;
				//入数组
				buff[buffLen++] = pTemp;
			}
			else  //不能走
			{
				//释放内存
				free(pTemp);
				pTemp = NULL;
			}

		} // end of for (int i = 0; i < SIZE; i++)
#if 0
		for (int i = 0; i < buffLen; i++)
		{
			printf("%d:(%d,%d)g:%d,h:%d,f:%d\n", i,
				buff[i]->pos.row, buff[i]->pos.col,
				buff[i]->pos.g, buff[i]->pos.h, buff[i]->pos.f);
		}
		printf("=====================================\n");
		Sleep(100);
#endif
		//从数组中挑出f值最小的点
		minIdx = 0;	//假设第一个f值最小
		for (int i = 0; i < buffLen; i++)
		{
			minIdx = ((buff[minIdx]->pos.f < buff[i]->pos.f) ? minIdx : i);
		}
		//走
		pCurrent = buff[minIdx];
		drawMap(map, pCurrent->pos);
		Sleep(100);
		//标记走过
		isFindmap[pCurrent->pos.row][pCurrent->pos.col] = true;
		//把这个点从数组中删除
		for (int i = minIdx; i < buffLen - 1; i++)
		{
			buff[i] = buff[i + 1];
		}
		buffLen--;
		//判断是否找到终点
		if (pCurrent->pos.row == endPos.row &&
			pCurrent->pos.col == endPos.col)
		{
			isFindEnd = true;
			break;
		}
		//数组为空 循环结束
		if (0 == buffLen)
		{
			break;
		}
	}//end of while (1)


	//如果找到终点，打印路径
	if (isFindEnd)
	{
		printf("找到终点啦,哈哈哈哈哈！\n");
		printf("路径:");
		while (pCurrent)
		{
			printf("(%d,%d)", pCurrent->pos.row,
				pCurrent->pos.col);
			putimage(pCurrent->pos.col*SPACE + SPACE / 4,
				pCurrent->pos.row*SPACE + SPACE / 4,&pos);
			pCurrent = pCurrent->pParent;
		}
		printf("\n");
	}
	else
	{
		printf("糟糕，木有找到终点，呜呜呜呜呜呜呜！\n");
	}

	while (1);
	return 0;
}


//标记是否走过
bool canWalk(struct MyPoint pos, int map[ROWS][COLS], bool isFindmap[ROWS][COLS])
{
	if (pos.row < 0 || pos.row >= ROWS ||
		pos.col < 0 || pos.col >= COLS) return false;
	if (map[pos.row][pos.col]) return false; //有障碍物
	if (isFindmap[pos.row][pos.col]) return false;

	return true;
}

//贴图
void drawMap(int map[ROWS][COLS], struct MyPoint pos)
{
	for (int i = 0; i < ROWS; i++)
	{
		for (int j = 0; j < COLS; j++)
		{
			if (j == pos.col && i == pos.row)
			{
				putimage(j*SPACE, i*SPACE, &ren);
			}
			else
			{
				if (map[i][j])
				{
					putimage(j*SPACE, i*SPACE, &wall);
				}
				else
				{
					putimage(j*SPACE, i*SPACE, &road);
				}
			}
		}
	}
}

//创建树节点
struct treeNode* createTreeNode(struct MyPoint pos)
{
	struct treeNode* pNew = (struct treeNode*)malloc(sizeof(struct treeNode));
	if (NULL == pNew) return NULL;

	memset(pNew, 0, sizeof(struct treeNode));
	pNew->pos.row = pos.row;
	pNew->pos.col = pos.col;
	pNew->pos.g = pos.g;//注意
	return pNew;
}

//计算h值
int getH(struct MyPoint pos, struct MyPoint endPos)
{
	int x = ((pos.col > endPos.col) ? (pos.col - endPos.col) :
		(endPos.col - pos.col));
	int y = ((pos.row > endPos.row) ? (pos.row - endPos.row) :
		(endPos.row - pos.row));
	return (x + y)*ZXDJ;
}
