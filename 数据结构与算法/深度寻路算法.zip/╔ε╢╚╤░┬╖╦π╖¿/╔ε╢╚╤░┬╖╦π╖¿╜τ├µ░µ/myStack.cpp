#include "myStack.h"

#include <stdlib.h>
#include <string.h>


//��ʼ��ջ
void init(struct MyStack* s)
{
	if (NULL == s) return;
	s->pBuff = NULL;
	s->len = s->maxLen = 0;
}

//��ջ
void push(struct MyStack* s, struct MyPoint* data)
{
	if (NULL == s || data == NULL) return;
	if (s->maxLen <= s->len)
	{
		s->maxLen = s->maxLen
			+ (((s->maxLen / 2) > 1) ? (s->maxLen / 2) : 1);

		struct MyPoint* pNew = (struct MyPoint*)malloc(s->maxLen*MYPOINT_SIZE);
		if (s->pBuff)
		{
			memcpy(pNew, s->pBuff, s->len*MYPOINT_SIZE);
			free(s->pBuff);
		}
		s->pBuff = pNew;
	}
	s->pBuff[s->len].col = data->col;
	s->pBuff[s->len].row = data->row;
	s->len++;
}

//��ջ
void pop(struct MyStack* s)
{
	if (NULL == s) return;
	if (s->len > 0) s->len--;
}

//��ȡջ��Ԫ��
struct MyPoint* getTop(struct MyStack* s)
{
	if (NULL == s) return NULL;
	return s->pBuff + (s->len - 1);
}

//�ж�ջ�Ƿ�Ϊ��
bool isEmpty(struct MyStack* s)
{
	if (NULL == s) return true;
	return (s->len == 0);
}

