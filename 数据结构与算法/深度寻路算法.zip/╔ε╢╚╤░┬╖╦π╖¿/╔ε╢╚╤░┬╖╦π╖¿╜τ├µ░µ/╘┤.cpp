﻿#include "res.h"
#include "myStack.h"
#include <graphics.h>

#define SPACE 50

IMAGE img_pos, img_ren, img_road, img_wall;

void printMap(int map[ROWS][COLS], struct MyPoint* pos);

void initGame();
void showMap(int map[ROWS][COLS], struct MyPoint* pos);

int main()
{

	initGame();
	//地图
	int map[ROWS][COLS] = {
		{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
		{ 1, 0, 1, 1, 0, 1, 0, 0, 0, 1 },
		{ 1, 0, 1, 0, 0, 1, 0, 1, 0, 1 },
		{ 1, 0, 1, 0, 1, 1, 1, 1, 0, 1 },
		{ 1, 0, 1, 0, 0, 0, 1, 1, 0, 1 },
		{ 1, 0, 0, 0, 1, 0, 1, 1, 0, 1 },
		{ 1, 0, 1, 1, 1, 0, 0, 0, 0, 1 },
		{ 1, 0, 1, 1, 0, 0, 1, 0, 1, 1 },
		{ 1, 0, 1, 0, 0, 1, 1, 0, 0, 1 },
		{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }
	};

#if 0
	//标记走过
	bool isFind[ROWS][COLS] = { 0 };
	//记录当前点的当前试探方向
	int dir[ROWS][COLS] = { 0 };
#else
	//辅助地图
	struct pathNode pathMap[ROWS][COLS] = { 0 };
#endif
	//准备一个栈
	struct MyStack stack;
	init(&stack);
#if 0
	// 准备一个栈
	struct MyStack stack;
	struct MyPoint test[] =
	{
		{ 1, 1 }, { 2, 1 }, { 3, 1 }, { 4, 1 }, { 5, 1 }
	};

	init(&stack);
	for (int i = 0; i < 5; i++)
	{
		push(&stack, &(test[i]));
	}

	while (!isEmpty(&stack))
	{
		printf("(%d,%d) ", getTop(&stack)->row, getTop(&stack)->col);
		pop(&stack);
	}
#endif

	//起点
	struct MyPoint begPos = { 1, 1 };
	//终点
	struct MyPoint endPos = { 8, 8 };

	//标记起点走过
	pathMap[begPos.row][begPos.col].isFind = true;
	//起点入栈
	push(&stack, &begPos);

	struct MyPoint currentPos = begPos;
	struct MyPoint searchPos;

	bool isFindEnd = false;
	while (1)
	{
		//循环寻路
		//找出试探点
		searchPos = currentPos;
		switch (pathMap[currentPos.row][currentPos.col].dir)
		{
		case p_up:
			searchPos.row--;
			// 当前点试探方向改变 
			pathMap[currentPos.row][currentPos.col].dir = p_right;
			//判断试探点能不能走
			// 当前点的当前试探方向，决定了试探点的位置
			if (wall != map[searchPos.row][searchPos.col] &&
				//没有走过
				true != pathMap[searchPos.row][searchPos.col].isFind)
			{
				// 能走
				// 入栈 
				push(&stack, &searchPos);
				// 标记走过
				pathMap[searchPos.row][searchPos.col].isFind = true;
				// 走
				currentPos = searchPos;
			}
			break;
		case p_right:
			searchPos.col++;
			// 当前点试探方向改变 
			pathMap[currentPos.row][currentPos.col].dir = p_down;
			//判断试探点能不能走
			// 当前点的当前试探方向，决定了试探点的位置
			if (wall != map[searchPos.row][searchPos.col] &&
				//没有走过
				true != pathMap[searchPos.row][searchPos.col].isFind)
			{
				// 能走
				// 入栈 
				push(&stack, &searchPos);
				// 标记走过
				pathMap[searchPos.row][searchPos.col].isFind = true;
				// 走
				currentPos = searchPos;
			}

			break;
		case p_down:
			searchPos.row++;
			// 当前点试探方向改变 
			pathMap[currentPos.row][currentPos.col].dir = p_left;
			//判断试探点能不能走
			// 当前点的当前试探方向，决定了试探点的位置
			if (wall != map[searchPos.row][searchPos.col] &&
				//没有走过
				true != pathMap[searchPos.row][searchPos.col].isFind)
			{
				// 能走
				// 入栈 
				push(&stack, &searchPos);
				// 标记走过
				pathMap[searchPos.row][searchPos.col].isFind = true;
				// 走
				currentPos = searchPos;
			}
			break;
		case p_left:
			searchPos.col--;
			// 当前点试探方向改变 
			pathMap[currentPos.row][currentPos.col].dir = p_down;
			//判断试探点能不能走
			// 当前点的当前试探方向，决定了试探点的位置
			if (wall != map[searchPos.row][searchPos.col] &&
				//没有走过
				true != pathMap[searchPos.row][searchPos.col].isFind)
			{
				// 能走
				// 入栈 
				push(&stack, &searchPos);
				// 标记走过
				pathMap[searchPos.row][searchPos.col].isFind = true;
				// 走
				currentPos = searchPos;
			}
			else
			{
				// 不能走

				// 出栈
				pop(&stack);
				// 跳到当前栈顶元素处
				struct MyPoint* temp = getTop(&stack);
				currentPos.row = temp->row;
				currentPos.col = temp->col;
			}
			break;
		}

		Sleep(10);
		printMap(map, &currentPos);
		showMap(map, &currentPos);

		//判断是否找到终点
		if (endPos.row == currentPos.row &&
			endPos.col == currentPos.col)
		{
			isFindEnd = true;
			break;
		}
		//判断栈是否为空
		if (isEmpty(&stack)) break;
	}

	int x, y;
	//找到终点了
	if (isFindEnd)
	{
		printf("找到终点了！\n");
		//打印路径
		printf("path:");while (!isEmpty(&stack))
		{
			x = getTop(&stack)->col;
			y = getTop(&stack)->row;
			printf("(%d,%d) ", y,x);
			putimage(x*SPACE + SPACE / 4, 
				y*SPACE + SPACE / 4, 
				&img_pos);
			pop(&stack);
		}
		printf("\n");
	}
	else
	{
		printf("出西西了，木有找到终点！\n");
	}

	getchar();
	return 0;
}

void initGame()
{
	initgraph(COLS*SPACE, ROWS*SPACE, SHOWCONSOLE);

	loadimage(&img_ren, L"ren.bmp", SPACE, SPACE, true);
	loadimage(&img_road, L"road.bmp", SPACE, SPACE, true);
	loadimage(&img_wall, L"wall.bmp", SPACE, SPACE, true);
	loadimage(&img_pos, L"pos.bmp", SPACE/2, SPACE/2, true);
}

void printMap(int map[ROWS][COLS], struct MyPoint* pos)
{
	system("cls");
	for (int i = 0; i < ROWS; i++)
	{
		for (int j = 0; j < ROWS; j++)
		{
			if (pos->row == i && pos->col == j)
			{
				printf("人");
			}
			else
			{
				if (map[i][j])
				{
					printf("墙");
				}
				else
				{
					printf("  ");
				}
			}
		}
		printf("\n");
	}
}

void showMap(int map[ROWS][COLS], struct MyPoint* pos)
{
	for (int i = 0; i < ROWS; i++)
	{
		for (int j = 0; j < COLS; j++)
		{
			if (pos->row == i && pos->col == j)
			{
				putimage(j*SPACE, i*SPACE, &img_ren);
			}
			else
			{
				if (map[i][j])
				{
					putimage(j*SPACE, i*SPACE, &img_wall);
				}
				else
				{
					putimage(j*SPACE, i*SPACE, &img_road);
				}
			}
		}
	}
}