#include "myTree.h"


//�������ڵ�ĺ���
struct treeNode* createNode(int row, int col)
{
	struct treeNode* pNew = malloc(sizeof(struct treeNode));
	if (NULL == pNew) return NULL;
	//��ʼ��Ϊ0
	memset(pNew, 0, sizeof(struct treeNode));
	pNew->pos.row = row;
	pNew->pos.col = col;
	return pNew;
}
