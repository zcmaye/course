#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define ROWS 10
#define COLS 10

enum dir{ p_up, p_down, p_left, p_right };

struct MyPoint
{
	int row, col;
};
