#pragma once
#include "myTree.h"

bool canWalk(struct MyPoint pos, int map[ROWS][COLS], bool isFind[ROWS][COLS]);